package com.infy.person.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.person.entity.EmployeeEntity;

public interface EmployeeRepo extends JpaRepository<EmployeeEntity, Integer> {

}
