package com.infy.person.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infy.person.dto.EmployeeDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="EMPLOYEE_DETAILS")
//@Getter
//@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmployeeEntity {

	@Id
	@Column(name="EMPLOYEE_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int employeeId;
	
	@Column(name="EMPLOYEE_NAME")
	private String employeeName;
	
	@Column(name="EMPLOYEE_JOB")
	private String job;
	
	@Column(name="EMPLOYEE_AGE")
	private int age;
	
	@Column(name="EMPLOYEE_HEIGHT")
	private float height;
	
	@Column(name="EMPLOYEE_WEIGHT")
	private float weight;
	
	@Column(name="EMPLOYEE_DESCRIPTION")
	private String description;
	
	public void prepareEntity(EmployeeDTO employeeDTO) {
		this.employeeName = employeeDTO.getEmployeeName();
		this.age = employeeDTO.getAge();
		this.job = employeeDTO.getJob();
		this.height = employeeDTO.getHeight();
		this.weight = employeeDTO.getWeight();
		this.description = employeeDTO.getDescription();
	}
	
}
