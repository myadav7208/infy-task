package com.infy.person.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.infy.person.dto.EmployeeDTO;
import com.infy.person.dto.AllEmployeeResponseDTO;
import com.infy.person.entity.EmployeeEntity;
import com.infy.person.exception.EmployeeException;

public interface EmployeeService {

	int registerEmployee(EmployeeDTO employeeDTO) throws EmployeeException;
	
	void updateEmployeeDetails(int employeeId, EmployeeDTO employeeDTO) throws EmployeeException;
	
	void deleteEmployeeDetails(int employeeId) throws EmployeeException;
	
	public Optional<EmployeeEntity> getEmployee(int employeeId) throws EmployeeException;
	
	public List<AllEmployeeResponseDTO> getAllEmployee(int pageNo, int pageSize, String[] sortBy);
}
