package com.infy.person.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AllEmployeeResponseDTO {

	private int employeeId;
	
	private String employeeName;
	
	private int age;
	
	private String job;
}
