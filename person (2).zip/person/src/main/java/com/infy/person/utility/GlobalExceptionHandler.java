package com.infy.person.utility;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.infy.person.exception.EmployeeException;


@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	Environment environment;
	
	public ResponseEntity<ErrorInfo> generalExceptionHandler(Exception exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(environment.getProperty("General.EXCEPTION_MESSAGE"));
		errorInfo.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errorInfo.setTimestamp(LocalDateTime.now());
		return new ResponseEntity<>(errorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(EmployeeException.class)
	public ResponseEntity<ErrorInfo> employeeExceptionHandler(EmployeeException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(environment.getProperty(exception.getMessage()));
		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorInfo.setTimestamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);

	}
	
	@Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid( MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        
        List<String> details = new ArrayList<String>();
        
        for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
            if (objectError instanceof FieldError) {
                FieldError fieldError = (FieldError) objectError;
                details.add(fieldError.getField() + " : "+ fieldError.getDefaultMessage());
            }
        }
        

                
        ErrorInfo err = new ErrorInfo(
            	"Validation erros" ,
                HttpStatus.BAD_REQUEST.value(),
                LocalDateTime.now(),
                details);
        
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorInfo> handleConstraintViolationException(
        Exception ex, 
        WebRequest request) {
        
        List<String> details = new ArrayList<String>();
        details.add(ex.getMessage());
        
        ErrorInfo err = new ErrorInfo(
        	"Constraint Violations" ,
            HttpStatus.BAD_REQUEST.value(),
            LocalDateTime.now(),
            details);
        
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFoundException(
            ResourceNotFoundException ex) {
       
        List<String> details = new ArrayList<String>();
        details.add(ex.getMessage());
        
        ErrorInfo err = new ErrorInfo(
        	"Resource not found",
        	HttpStatus.BAD_REQUEST.value(), 
            LocalDateTime.now(),
            details);
        
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ErrorInfo> handleEntityNotFoundException(
            EntityNotFoundException ex) {
       
        List<String> details = new ArrayList<String>();
        details.add(ex.getMessage());
        
        ErrorInfo err = new ErrorInfo(
        	"Entity not found",
        	HttpStatus.BAD_REQUEST.value(), 
            LocalDateTime.now(),
            details);
        
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }
    
    
    @ExceptionHandler({ Exception.class })
    public ResponseEntity<ErrorInfo> handleAll(
        Exception ex, 
        WebRequest request) {
        
        List<String> details = new ArrayList<String>();
        details.add(ex.getLocalizedMessage());
        
        
        ErrorInfo err = new ErrorInfo(
        		"Error occurred" ,
        		HttpStatus.BAD_REQUEST.value(), 
            LocalDateTime.now(),
            details);
        
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }
	
	
}
