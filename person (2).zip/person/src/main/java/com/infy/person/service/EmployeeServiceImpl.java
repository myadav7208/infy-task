package com.infy.person.service;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Service;

import com.infy.person.dto.AllEmployeeResponseDTO;
import com.infy.person.dto.EmployeeDTO;
import com.infy.person.entity.EmployeeEntity;
import com.infy.person.exception.EmployeeException;
import com.infy.person.repository.EmployeeRepo;
import com.infy.person.utility.ResourceNotFoundException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	

	@Override
	@Caching(put = @CachePut(cacheNames = "Employee"),
    evict = @CacheEvict(cacheNames = "Employees", allEntries = true))
	public int registerEmployee(EmployeeDTO employeeDTO) throws EmployeeException {
		System.out.print("--------register employee cache----------");
		EmployeeEntity employee = new EmployeeEntity();
		employee.prepareEntity(employeeDTO);
		
		employee = employeeRepo.save(employee);
		
		return employee.getEmployeeId();
		
	}

	@Override
	@Caching(put = @CachePut(cacheNames = "Employee"),
    evict = @CacheEvict(cacheNames = "Employees", allEntries = true))
	public void updateEmployeeDetails(int employeeId, EmployeeDTO employeeDTO) throws EmployeeException{
		System.out.print("--------update employee cache----------");
		EmployeeEntity employee  = new EmployeeEntity();
		employee = employeeRepo.getById(employeeId);
		if(employee != null) {
			EmployeeDTO newEmployeeDTO = new EmployeeDTO();
			newEmployeeDTO.prepareEmployeeDTO(employeeId, employeeDTO);

			employee.prepareEntity(newEmployeeDTO);
			employeeRepo.save(employee);
		}else {
			throw new ResourceNotFoundException("Details not found with provided employee Id : "+employeeId);
		}

	} 

	@Override
	@Caching(put = @CachePut(cacheNames = "Employee"),
    evict = @CacheEvict(cacheNames = "Employees", allEntries = true))
	public void deleteEmployeeDetails(int employeeId) throws EmployeeException {
		System.out.print("--------delete employee cache----------");
		if(employeeRepo.getById(employeeId) != null) {
			employeeRepo.deleteById(employeeId);
		}else {
			throw new ResourceNotFoundException("Details not found with provided employee Id : "+employeeId);
		}
	}

	@Override
	@Cacheable("Employees")
	public Optional<EmployeeEntity> getEmployee(int employeeId) throws EmployeeException { 
		System.out.print("--------employee cache----------");
		Optional<EmployeeEntity> employeeEntity = employeeRepo.findById(employeeId);
		if(employeeEntity != null)
			return employeeEntity;
		else
			throw new EmployeeException("Details not found with provided employee Id : "+employeeId);
	}

	
	
	
	
	@Override
    @Cacheable(cacheNames = "Employees")
	public List<AllEmployeeResponseDTO> getAllEmployee(int pageNo, int pageSize, String[] sortBy) {
		System.out.println("--------All employee cache---------");

		List<Order> orders = new ArrayList<Order>();
		Pageable pageable = PageRequest.of(0, 10);

		if(!sortBy.equals(null)) {
		
			if (sortBy[0].contains(",")) {
		        // will sort more than 2 fields
		        // sortOrder="field, direction"
		        for (String sortOrder : sortBy) {
		          String[] _sort = sortOrder.split(",");
		          orders.add(new Order(getSortDirection(_sort[1]), _sort[0]));
		        }
		      } else {
		        orders.add(new Order(getSortDirection(sortBy[1]), sortBy[0]));
		      }
			pageable = PageRequest.of(pageNo, pageSize, Sort.by(orders));

		}else {
			pageable = PageRequest.of(pageNo, pageSize);

		}

		
		Page<EmployeeEntity> pageResult = (Page<EmployeeEntity>) employeeRepo.findAll(pageable);
		List<AllEmployeeResponseDTO> AllEmployeeResponse = new ArrayList<AllEmployeeResponseDTO>();
		for(EmployeeEntity employee:pageResult) {
			AllEmployeeResponseDTO employeeResponse = new AllEmployeeResponseDTO(
					employee.getEmployeeId(),
					employee.getEmployeeName(),
					employee.getAge(),
					employee.getJob() );
			
			AllEmployeeResponse.add(employeeResponse);
		}
		return AllEmployeeResponse;
	}
	
	
	private Sort.Direction getSortDirection(String direction) {
	    if (direction.equals("asc")) {
	      return Sort.Direction.ASC;
	    } else if (direction.equals("desc")) {
	      return Sort.Direction.DESC;
	    }

	    return Sort.Direction.ASC;
	  }
	

}
