package com.infy.person.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeDTO {

	private int id;
	
	@NotEmpty(message= "{name.absent}")
	@Pattern(regexp="^[a-zA-Z\\s]*$", message="{invalid.person.name.format}")
	private String employeeName;
	
	@NotNull(message= "{age.absent}")
	@Range(min=1, message="{invalid.age.format}")
	private int age;
	
	@NotEmpty(message= "{job.absent}")
	private String job;
	
	@NotNull(message= "{height.absent}")
	@Range(min=1, message="{invalid.height.format}")
	private float height;
	
	@NotNull(message= "{weight.absent}")
	@Range(min=1, message="{invalid.weight.format}")
	private float weight;
	
	@Size(max=149)
	private String description;
	
	public void prepareEmployeeDTO(int employeeId, EmployeeDTO employeeDTO) {
		this.id = employeeId;
		this.age = employeeDTO.getAge();
		this.employeeName = employeeDTO.getEmployeeName();
		this.description = employeeDTO.getDescription();
		this.height = employeeDTO.getHeight();
		this.weight = employeeDTO.getWeight();
		this.job = employeeDTO.getJob();
	}
	
	
}
