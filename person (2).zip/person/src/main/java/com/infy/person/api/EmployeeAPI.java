package com.infy.person.api;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.person.dto.AllEmployeeResponseDTO;
import com.infy.person.dto.EmployeeDTO;
import com.infy.person.entity.EmployeeEntity;
import com.infy.person.exception.EmployeeException;
import com.infy.person.service.EmployeeService;

@CrossOrigin
@RestController
@RequestMapping("/employee-api")
public class EmployeeAPI {

	@Autowired
	private Environment environment;
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/{employeeId}")
	public ResponseEntity<Optional<EmployeeEntity>> getEmployee(@PathVariable int employeeId) throws EmployeeException {
		return new ResponseEntity<>(employeeService.getEmployee(employeeId), HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<AllEmployeeResponseDTO>> getAllEmployee(@RequestParam(defaultValue="0") int pageNo,
			@RequestParam(defaultValue="10") int pageSize,
			@RequestParam(defaultValue = "employeeId,asc") String[] sortBy){
		
			return new ResponseEntity<>(employeeService.getAllEmployee(pageNo, pageSize, sortBy), HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<String> employee(@Validated @RequestBody EmployeeDTO employeeDTO) throws EmployeeException{
		int employeeId = employeeService.registerEmployee(employeeDTO);
		String message = environment.getProperty("PersonAPI.PERSON_REGISTRATION_SUCCESS") + employeeId;
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}
	
	@PutMapping("/{employeeId}")
	public ResponseEntity<String> employeeUpdate (@Validated @RequestBody EmployeeDTO employeeDTO, 
			@Range(min=1, message="Employee id should not be empty") @PathVariable int employeeId) throws EmployeeException{
		
		employeeService.updateEmployeeDetails(employeeId, employeeDTO);
		String message = environment.getProperty("PersonAPI.PERSON_DETAILS_UPDATION_SUCCESS");
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	@DeleteMapping("/{employeeId}")
	public ResponseEntity<String> employeeDelete(@Range(min=1, message="Employee id should not be empty") @PathVariable int employeeId) throws EmployeeException{
		employeeService.deleteEmployeeDetails(employeeId);
		return new ResponseEntity<>(environment.getProperty("PersonAPI.PERSON_DELETED_SUCCESS"), HttpStatus.OK);
	}
	
	
	
}
