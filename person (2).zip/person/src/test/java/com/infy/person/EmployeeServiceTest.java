package com.infy.person;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.infy.person.entity.EmployeeEntity;
import com.infy.person.repository.EmployeeRepo;
import com.infy.person.service.EmployeeService;

@SpringBootTest
public class EmployeeServiceTest {

	@Mock
	EmployeeRepo employeeRepo;
	
	@InjectMocks
	EmployeeService employeeService;
	
	@Test
	@Order(1)
	public void test_getAllEmployee() {
		
		List<EmployeeEntity> employeeEntity = new ArrayList<EmployeeEntity>();
		employeeEntity.add(new EmployeeEntity(1, "Manish Yadav", "Software Engineer", 22, 65, 65, ""));
		employeeEntity.add(new EmployeeEntity(1, "Akash Yadav", "Software Engineer", 22, 65, 65, ""));
		Pageable pageable = PageRequest.of(0, 10);

		when(employeeRepo.findAll(pageable)).thenReturn((Page<EmployeeEntity>) employeeEntity);
		//employeeService.getAllEmployee(0, 2, null);
		
		assertEquals(2, employeeService.getAllEmployee(0, 0, null).size());

	}
	
	
}
