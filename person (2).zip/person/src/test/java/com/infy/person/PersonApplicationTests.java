package com.infy.person;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonApplicationTests {

	@Test
	void contextLoads() {
	}

}
